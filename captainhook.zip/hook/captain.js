// Install service worker
self.addEventListener('install', function(event) {
  console.log('Service worker installed');
});

// Activate service worker
self.addEventListener('activate', function(event) {
  console.log('Service worker activated');
});

// Listen for fetch events
self.addEventListener('fetch', function(event) {
  console.log('Fetch event:', event.request.url);
  // You can add your custom logic for handling fetch requests here
});

// Listen for message events from client
self.addEventListener('message', function(event) {
  console.log('Message event:', event.data);
  // You can add your custom logic for handling messages from client here
});

// Retrieve data from chrome storage
//chrome.storage.local.get(null, function(data) {
   // console.log('Data retrieved from chrome storage:', data);
	
// Update the HTML element with the retrieved data
    //document.getElementById('treasure').innerHTML = JSON.stringify(data);
//});

// Retrieve data from chrome storage
chrome.storage.local.get(null, function(data) {
    console.log('Data retrieved from chrome storage:', data);

    // Get the HTML element to update
    const treasureElement = document.getElementById('treasure');

    // Loop through each item in the data object and create a new element for each line
    for (const key in data) {
        const line = document.createElement('div');
        line.innerHTML = `${key.bold()}: ${JSON.stringify(data[key])}`;
        if (key === 'chest_json' || key === 'chest_local' || key === 'chest_postmessage') {
            line.firstChild.style.display = 'inline-block';
            line.firstChild.style.backgroundColor = 'gold';
            line.firstChild.style.color = 'black';
            line.firstChild.style.fontWeight = 'bold';
            line.firstChild.style.padding = '3px 7px 3px 7px';
            line.firstChild.style.borderRadius = '3px';
        } else {
            line.firstChild.style.display = 'inline-block';
            line.firstChild.style.backgroundColor = 'black';
            line.firstChild.style.color = 'white';
            line.firstChild.style.fontWeight = 'bold';
            line.firstChild.style.padding = '3px 7px 3px 7px';
            line.firstChild.style.borderRadius = '3px';
}

        treasureElement.appendChild(line);
    }
});


