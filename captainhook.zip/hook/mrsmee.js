  const textarea = document.getElementById('code');
  const urlInput = document.getElementById('url');
  const beautifyCode = (code) => {
    try {
      return js_beautify(code, {indent_size: 2});
    } catch (e) {
      console.error('Failed to beautify code:', e);
      return code;
    }
  };
  
  urlInput.addEventListener('change', () => {
    const fileUrl = urlInput.value;
    if (!fileUrl) return;
    fetch(fileUrl)
      .then(response => response.text())
      .then(code => {
        textarea.value = beautifyCode(code);
      })
      .catch(error => console.error(`Failed to fetch ${fileUrl}`, error));
  });
