// Clear chrome.storage.local
//chrome.storage.local.clear();

// Empty the storage items
const emptyObj = { "chest_json": [], "chest_local": {}, "chest_postmessage": [] };
chrome.storage.local.set(emptyObj, function() {
    console.log('chest items emptied:', emptyObj);
});

// Create the chest_search object with initial values
//const chest_search = ['user', 'demo', '/reset', '/forgot'];

// Save the chest_search object to chrome.storage.local
//chrome.storage.local.set({ chest_search }, () => {
 // console.log('chest_search saved:', chest_search);
//});


chrome.storage.local.get('chest_search', function(result) {
  console.log(result.chest_search);
});


// Prevent console clear
console.clear = function() {};

// Extract localStorage and sessionStorage data
console.log(`%cLocal Storage:`,"display: inline-block ; background-color: #e0005a ; color: #ffffff ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;");

const chest_local = [];

// Loop through localStorage and copy to data object
for (let i = 0; i < localStorage.length; i++) {
  const key = localStorage.key(i);
  const value = localStorage.getItem(key);
  console.log(`${key}: ${value}`);
  chest_local[key] = value;
  chest_local.push(value);
}
// Store data in chrome.storage.local
chrome.storage.local.set({chest_local}, function() {
  console.log('localStorage copied to chest_localStorage', chest_local);
});

console.log(`%cSession Storage:`,"display: inline-block ; background-color: #e0005a ; color: #ffffff ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;");

for (let i = 0; i < sessionStorage.length; i++) {
  const key = sessionStorage.key(i);
  const value = sessionStorage.getItem(key);
  console.log(`${key}: ${value}`);
}
// Logs localStorage.setItem

// Define a regular expression to search for 'localStorage.setItem'
//const localStorageRegex = /localStorage\.setItem\s*\(\s*(['"`])(?:(?!\1)[^'"`])*\1\s*,\s*([^)]+)\)|(['"`])(?:(?!\3)[^'"`])*\b(?:oauth|oauth2|graphql|api\/|\/login|\/register|\/jwt|jwt\/|\/token|\/account|\/password|secret|admin|eyJ|\.json)\b(?:(?!\3)[^'"`])*\3/g;

// Define the regular expression to match local storage and postMessage calls
const localStorageRegex = /localStorage\.setItem\s*\(\s*(['"`])(?:(?!\1)[^'"`])*\1\s*,\s*([^)]+)\)|postMessage\s*\(\s*(['"`])(?:(?!\3)[^'"`])*\3\s*,\s*([^)]+)\)|(['"`])(?:(?!\5)[^'"`])*\b(?:oauth|oauth2|graphql|api\/|\/login|\/register|\/jwt|jwt\/|\/token|\/account|\/password|secret|admin|eyJ|\.json|postMessage|authorization)\b(?:(?!\5)[^'"`])*\5/gi;

// Retrieve the value of 'chest_search' from chrome.storage.local
chrome.storage.local.get('chest_search', function(result) {
  // Provide a default value if chest_search is not found
  const chestSearch = result.chest_search || ['/tmp'];

  // Combine the value of 'chest_search' with the regular expression
  const Regex = new RegExp(chestSearch.join('|'), 'gi');

  // Get all the script elements on the page
  const scriptElements = document.getElementsByTagName("script");

  // Iterate over each script element and get the source URL
  for (let i = 0; i < scriptElements.length; i++) {
    const src = scriptElements[i].src;
    if (src) {
      // Fetch the contents of the script URL using the fetch() method
      fetch(src, { mode: 'no-cors' })
        .then((response) => response.text())
        .then((text) => {
          // Perform a regular expression search on the contents of the script
          let match;
          while ((match = Regex.exec(text) || localStorageRegex.exec(text)) !== null) {
            // Set background-color to yellow if match is found by regex, otherwise set it to gold
            const backgroundColor = match.index !== undefined ? "gold" : "grey";
            console.log(`Found Keyword at index ${match.index} in ${src}: %c${match[0]}`, `display: inline-block ; background-color: ${backgroundColor} ; color: black ; font-weight: bold ; padding:3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;`);
          }
        })
        .catch((error) => {
          console.error(`Failed to fetch ${src}`, error);
        });
    }
  }
});



// Listen for postMessage events
window.addEventListener('message', function (e) {
  console.log(`%cpostMessage received:`, "display: inline-block ; background-color: green ; color: white ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;", e.data);
  console.log("Domain: ", window.location.hostname);
  console.log("URL: ", window.location.href);
  console.log("Path: ", window.location.pathname);
  console.log("Sender origin: ", e.origin);

  // Save the message data in chrome.storage
  //chrome.storage.local.set({ 'chest': e.data }, function () {
  //console.log('Data saved in chrome.storage.');
  //});
  chrome.storage.local.get({ chest_postmessage: [] }, function (data) {
    data.chest_postmessage = data.chest_postmessage || []; // make sure it's an array
    data.chest_postmessage.push(e.data);
    chrome.storage.local.set({ chest_postmessage: data.chest_postmessage }, function () {
      console.log('PostMessage saved to chest_postmessage');
    });
  });

  // Forward the message to captain.js
  if (navigator.serviceWorker && navigator.serviceWorker.controller) {
    navigator.serviceWorker.controller.postMessage(e.data);
  }
});

// Log domain, URL, and path of iframes

const iframes = document.getElementsByTagName('iframe');
for (let i = 0; i < iframes.length; i++) {
  const iframe = iframes[i];
  console.log(`%cIframe Loaded: domain=${iframe.contentWindow.location.hostname}, url=${iframe.src}, path=${iframe.contentWindow.location.pathname}`,"display: inline-block ; background-color: black ; color: white ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;");
}

// Log JSON Object

fetch(window.location.href)
  .then(response => response.text())
  .then(data => {
    const regex = /({.*})/g;
    let match;
    const chest_json = []; // create an array to store the results
    while ((match = regex.exec(data)) !== null) {
      try {
        console.log(`%cJSON Object:`,"display: inline-block ; background-color: blue ; color: white ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;");
        const obj = JSON.parse(match[1]);
        for (const prop in obj) {
          console.log(`${prop}: ${obj[prop]}`);
        }
        chest_json.push(obj); // add the result object to the array
      } catch (e) {
        console.error(e);
      }
    }
    // store the array of results in Chrome storage
    chrome.storage.local.set({ chest_json }, function() {
      console.log('JSON Object stored in chest_json', chest_json);
    });
  })
  .catch(error => console.error(error));

