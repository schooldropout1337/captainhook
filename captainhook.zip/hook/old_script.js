// Load the content of chest_search into the input field
chrome.storage.local.get('chest_search', function (data) {
  const regexArray = Array.isArray(data.chest_search) ? data.chest_search : [];
  const regexText = regexArray.join(',');
  document.getElementById('regex').value = regexText;
});

// Save the updated content back into chest_search
function saveRegex() {
  const updatedRegex = document.getElementById('regex').value;
  const regexArray = updatedRegex.split(',').filter(Boolean);
  if (regexArray.length > 0) {
    chrome.storage.local.set({ 'chest_search': regexArray }, function () {
      console.log('Regex updated:', regexArray);
      alert('Regex updated successfully');
      window.location.reload();

    });
  } else {
    alert('Please enter at least one search term');
  }
}

// Bind the save button to saveRegex function
document.getElementById('save-button').addEventListener('click', saveRegex);


// Bind the delete button to remove the 'chest_search' key from storage
document.getElementById('delete-button').addEventListener('click', deleteRegex);

function deleteRegex() {
  chrome.storage.local.remove('chest_search', function () {
    console.log('Regex deleted');
    alert('Regex deleted successfully');
    window.location.reload();
  });
}

